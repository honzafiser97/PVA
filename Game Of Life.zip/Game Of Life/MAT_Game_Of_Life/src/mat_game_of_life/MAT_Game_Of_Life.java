package mat_game_of_life;

public class MAT_Game_Of_Life {
    public static void main(String[] args) {
        new view.View().setVisible(true);
        
    }
}
